#ifndef TESTER_H
#define TESTER_H

#include "StrokeRiskPredictor.h"
#include <cassert>
#include <iostream>

class Tester {
public:
    static void runTests();
};

#endif