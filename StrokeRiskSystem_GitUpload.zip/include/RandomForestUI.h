#ifndef RANDOM_FOREST_UI_H
#define RANDOM_FOREST_UI_H

class RandomForestUI {
public:
    void run();
};

#endif